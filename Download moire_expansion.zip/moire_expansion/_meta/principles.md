# Additional Principles of Moiré

6. **Phase is character** — Frequency determines what kind of beat exists, but phase determines personality. Tiny phase shifts can make the same setup feel rigid, ghostly, liquid or breathing.

7. **Moiré is a difference amplifier** — It magnifies tiny structural disagreements into visible structures.

8. **Interference creates false objects** — Moiré produces forms that are not literally present in either source layer. They are apparitions born of relational difference.

9. **Legibility lives at the threshold** — Too aligned is boring, too chaotic is mud. The sweet spot is near collapse.

10. **Moiré is compression leakage** — Digital moiré reveals the mismatch between continuous reality and discrete representation. It is the residue of sampling and quantization.
